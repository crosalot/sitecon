/* Site connection */

=======================
Server
=======================
- For client register/key go to http://server.con/sitecon/server/register

=======================
Client
=======================
- Get key from server(http://server.con/sitecon/server/register) and add key to client that way go to http://client.con/sitecon/client/add
- You can see all servers domain at http://client.con/sitecon/client and edit/delete domain
- Connect to server
  1. Go to url: http://client/sitecon/client/connect/server.com
  2. Use function sitecon_client_connect('server.com')

/* Power by @opendream */